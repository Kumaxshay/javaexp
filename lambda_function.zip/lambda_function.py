import boto3
import json
import os
import urllib.parse

rekognition = boto3.client("rekognition")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("ImageLabels")

def lambda_handler(event, context):
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = urllib.parse.unquote_plus(record['s3']['object']['key'])

        response = rekognition.detect_labels(
            Image={"S3Object": {"Bucket": bucket, "Name": key}},
            MaxLabels=10
        )

        labels = [label["Name"] for label in response["Labels"]]

        table.put_item(Item={
            "filename": key,
            "labels": labels
        })

        return {
            'statusCode': 200,
            'body': json.dumps('Labels saved to DynamoDB')
        }
